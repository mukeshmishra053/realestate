<x-core::navbar.badge-count class="unread-contacts" />
