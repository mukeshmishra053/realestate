<x-core::button type="button" data-bb-toggle="add-option" icon="ti ti-plus">
    {{ trans('plugins/contact::contact.custom_field.option.add') }}
</x-core::button>
