<?php

if (! defined('CONTACT_MODULE_SCREEN_NAME')) {
    define('CONTACT_MODULE_SCREEN_NAME', 'contact');
}

if (! defined('CONTACT_UNREAD_COUNT')) {
    define('CONTACT_UNREAD_COUNT', 'contact_unread_count');
}

if (! defined('CONTACT_FORM_TEMPLATE_VIEW')) {
    define('CONTACT_FORM_TEMPLATE_VIEW', 'contact-form-template-view');
}
