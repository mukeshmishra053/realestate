<?php

namespace Botble\Contact\Repositories\Caches;

use Botble\Contact\Repositories\Eloquent\ContactReplyRepository;

/**
 * @deprecated
 */
class ContactReplyCacheDecorator extends ContactReplyRepository
{
}
