<?php

namespace Botble\Block\Repositories\Caches;

use Botble\Block\Repositories\Eloquent\BlockRepository;

/**
 * @deprecated
 */
class BlockCacheDecorator extends BlockRepository
{
}
