<?php

if (! defined('BLOCK_MODULE_SCREEN_NAME')) {
    define('BLOCK_MODULE_SCREEN_NAME', 'block');
}
