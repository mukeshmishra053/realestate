<?php

return [
    'name' => 'Block',
    'create' => 'New block',
    'menu' => 'Static Blocks',
    'static_block_short_code_name' => 'Static block',
    'static_block_short_code_description' => 'Add a custom static block',
    'alias' => 'Alias',
];
