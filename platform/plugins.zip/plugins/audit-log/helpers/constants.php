<?php

if (! defined('AUDIT_LOG_MODULE_SCREEN_NAME')) {
    define('AUDIT_LOG_MODULE_SCREEN_NAME', 'audit-log');
}
