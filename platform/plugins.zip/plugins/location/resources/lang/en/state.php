<?php

return [
    'name' => 'States',
    'description' => 'Manage location states',
    'create' => 'New state',
    'country' => 'Country',
    'select_country' => 'Select a country...',
    'state' => 'State',
];
