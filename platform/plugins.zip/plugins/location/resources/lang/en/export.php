<?php

return [
    'name' => 'Location Exporter',
];
