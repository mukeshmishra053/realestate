<?php

return [
    'name' => 'Cities',
    'description' => 'Manage location cities',
    'create' => 'New city',
    'state' => 'State',
    'select_state' => 'Select state...',
    'select_city' => 'Select city...',
    'country' => 'Country',
    'select_country' => 'Select country...',
    'city' => 'City',
];
