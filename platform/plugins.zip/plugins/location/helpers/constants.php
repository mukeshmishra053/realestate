<?php

if (! defined('COUNTRY_MODULE_SCREEN_NAME')) {
    define('COUNTRY_MODULE_SCREEN_NAME', 'country');
}

if (! defined('STATE_MODULE_SCREEN_NAME')) {
    define('STATE_MODULE_SCREEN_NAME', 'state');
}

if (! defined('CITY_MODULE_SCREEN_NAME')) {
    define('CITY_MODULE_SCREEN_NAME', 'city');
}
