<x-core::button color="primary" icon="ti ti-device-floppy" type="submit">
    {{ trans('core/setting::setting.save_settings') }}
</x-core::button>
