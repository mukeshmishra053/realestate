<div class="text-center language-column">{!! $data !!}</div>
