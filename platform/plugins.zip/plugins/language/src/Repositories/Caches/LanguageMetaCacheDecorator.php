<?php

namespace Botble\Language\Repositories\Caches;

use Botble\Language\Repositories\Eloquent\LanguageMetaRepository;

/**
 * @deprecated
 */
class LanguageMetaCacheDecorator extends LanguageMetaRepository
{
}
