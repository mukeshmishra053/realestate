<?php

namespace Botble\Language\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface LanguageMetaInterface extends RepositoryInterface
{
}
