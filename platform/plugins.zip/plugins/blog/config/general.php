<?php

return [
    'use_language_v2' => env('BLOG_USE_LANGUAGE_VERSION_2', true),
];
