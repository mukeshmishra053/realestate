<?php

namespace Botble\Blog\Repositories\Caches;

use Botble\Blog\Repositories\Eloquent\CategoryRepository;

/**
 * @deprecated
 */
class CategoryCacheDecorator extends CategoryRepository
{
}
