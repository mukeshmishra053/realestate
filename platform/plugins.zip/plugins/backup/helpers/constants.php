<?php

if (! defined('BACKUP_MODULE_SCREEN_NAME')) {
    define('BACKUP_MODULE_SCREEN_NAME', 'backup');
}

if (! defined('BACKUP_ACTION_AFTER_BACKUP')) {
    define('BACKUP_ACTION_AFTER_BACKUP', 'action_after_backup');
}

if (! defined('BACKUP_ACTION_AFTER_RESTORE')) {
    define('BACKUP_ACTION_AFTER_RESTORE', 'action_after_restore');
}
