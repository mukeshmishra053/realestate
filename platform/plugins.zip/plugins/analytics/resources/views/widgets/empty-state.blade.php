<x-core::empty-state
    icon="ti ti-exclamation-circle"
    :title="trans('plugins/analytics::analytics.not_set_up')"
    :subtitle="$message"
/>
