<x-core::alert
    type="warning"
    :title="BaseHelper::clean(trans('plugins/analytics::analytics.missing_library_warning'))"
/>
