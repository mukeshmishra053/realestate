@if(setting('captcha_hide_badge'))
    <style>
        .grecaptcha-badge { visibility: hidden; }
    </style>
@endif
