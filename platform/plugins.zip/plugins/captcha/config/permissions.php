<?php

return [
    [
        'name' => 'Captcha',
        'flag' => 'captcha.settings',
        'parent_flag' => 'settings.others',
    ],
];
